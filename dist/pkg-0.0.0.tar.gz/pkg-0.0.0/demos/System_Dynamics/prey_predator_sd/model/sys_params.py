"""
Model parameters.
"""

sys_params = {
    'prey_reproduction_rate': [0.3],
    'predator_interaction_factor': [0.0001],
    'prey_interaction_factor': [0.001],
    'prey_death_rate': [0.01],
    'predator_death_rate': [0.5],
    'dt': [0.1]
}
