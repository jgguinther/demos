

genesis_states = {
    'prey_population': 100,
    'predator_population': 50
}
