genesis_states = {
    'susceptible': 999990,
    'exposed': 10,
    'infected': 10,
    'recovered': 0,
}
