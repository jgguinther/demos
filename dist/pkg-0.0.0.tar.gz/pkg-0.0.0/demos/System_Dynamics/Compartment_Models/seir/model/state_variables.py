genesis_states = {
    'susceptible': 990,
    'exposed': 10,
    'infected': 0,
    'recovered': 0
}
