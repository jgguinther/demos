genesis_states = {
    'susceptible': 990,
    'infected': 10,
    'recovered': 0,
}
