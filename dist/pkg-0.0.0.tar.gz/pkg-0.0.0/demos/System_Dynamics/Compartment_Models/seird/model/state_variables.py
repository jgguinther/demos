genesis_states = {
    'susceptible': 9990,
    'exposed': 100,
    'infected': 0,
    'recovered': 0,
    'dead': 0
}
