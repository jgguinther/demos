from setuptools import setup, find_packages

with open('requirements.txt') as f:
    install_requires = [
        pkg for pkg in f.read().strip().split('\n')
            if not pkg.startswith('pkg-resources') and
               not pkg.startswith('cadCAD')
    ]

setup(
    name='pkg',
    version='0.0.0',
    packages=find_packages(),
    install_requires=install_requires,
    python_requires='>=3.6.8'
)