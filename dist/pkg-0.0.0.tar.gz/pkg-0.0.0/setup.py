from setuptools import setup, find_packages

necessary_pkgs = ['setuptools==56.2.0', 'IPython==7.16.1', 'nbformat==5.1.3']
with open('requirements.txt') as f:
    install_requires = [
        pkg for pkg in f.read().strip().split('\n')
            if not pkg.startswith('pkg-resources') and
               not pkg.startswith('cadCAD')
    ]
    for needed_pkg in necessary_pkgs:
        if needed_pkg not in install_requires:
            install_requires.append(needed_pkg)

setup(
    name='pkg',
    version='0.0.0',
    packages=find_packages(),
    install_requires=install_requires,
    python_requires='>=3.6.8'
)