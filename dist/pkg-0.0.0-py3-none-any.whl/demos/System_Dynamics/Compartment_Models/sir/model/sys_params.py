sys_params = {
        # 𝛽:  expected amount of people an infected person infects per day
        'infection_rate': [0.4],        
        # 𝛾: the proportion of infected recovering per day ( 𝛾  = 1/D)
        'recovering_rate': [1/14]
}
