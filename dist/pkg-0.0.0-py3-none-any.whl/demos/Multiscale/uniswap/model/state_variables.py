import pandas as pd

genesis_states = {
    'DAI_balance': 5900000000000000000000,
    'ETH_balance': 30000000000000000000,
    'UNI_supply': 30000000000000000000,
    'price_ratio': 0
}